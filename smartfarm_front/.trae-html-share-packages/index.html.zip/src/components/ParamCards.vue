<template>
  <section class="param-section" v-if="detail">
    <!-- 采集信息栏 -->
    <div class="info-bar">
      <div class="info-left">
        <span class="info-item">采集时间：<b>{{ detail.collectTime }}</b></span>
        <span class="info-item">
          采集间隔：<b>{{ detail.interval }}分钟</b>
          <button class="link" @click="openInterval">修改</button>
        </span>
        <span class="info-item battery">
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none">
            <rect x="2" y="7" width="17" height="10" rx="2" stroke="#3fd2a0" stroke-width="1.6"/>
            <rect x="4.5" y="9.5" width="9" height="5" rx="1" fill="#3fd2a0"/>
            <path d="M21 10v4" stroke="#3fd2a0" stroke-width="1.8" stroke-linecap="round"/>
          </svg>
          电池电压：<b>{{ detail.battery }}V</b>
        </span>
        <span class="info-item">
          设备状态：
          <i class="st-dot" :class="detail.online ? 'online' : 'offline'"></i>
          <b :class="detail.online ? 'st-online' : 'st-offline'">{{ detail.online ? '在线' : '离线' }}</b>
        </span>
      </div>
      <div class="info-right">
        <img class="device-img" :src="deviceImg" alt="设备图片" />
        <button class="link" @click="openRecords">修改记录</button>
        <button class="link" @click="openSettings">主机设置</button>
      </div>
    </div>

    <!-- 参数卡片 -->
    <div class="card-grid">
      <div
        v-for="p in detail.params"
        :key="p.key"
        class="card-wrap"
        :class="{ active: activeParam === p.key }"
        @click="$emit('select-param', p.key)"
      >
        <div class="card-inner">
          <div class="card-top">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" class="card-icon">
              <path d="M12 2.5C8 7 6 10.5 6 14a6 6 0 0 0 12 0c0-3.5-2-7-6-11.5z" stroke="#3fd2a0" stroke-width="1.5" stroke-linejoin="round"/>
              <path d="M12 8v10M9.5 12.5 12 14l2.5-1.5" stroke="#3fd2a0" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span class="card-name">{{ p.name }}</span>
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" class="card-swap">
              <path d="M4 8h13l-3-3M20 16H7l3 3" stroke="#5d7fc0" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-value">
            <b>{{ p.value }}</b>
            <span v-if="p.unit" class="card-unit">{{ p.unit }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 修改采集间隔 -->
    <BaseDialog v-model="showInterval" title="修改采集间隔" width="380px">
      <div class="form-row">
        <label>采集间隔</label>
        <input v-model.number="intervalForm" type="number" min="1" class="form-input" />
        <span class="form-unit">分钟</span>
      </div>
      <template #footer>
        <button class="btn ghost" @click="showInterval = false">取消</button>
        <button class="btn primary" @click="saveInterval">确定</button>
      </template>
    </BaseDialog>

    <!-- 修改记录 -->
    <BaseDialog v-model="showRecords" title="修改记录" width="560px">
      <table class="record-table">
        <thead>
          <tr><th>时间</th><th>修改项</th><th>修改前</th><th>修改后</th><th>操作人</th></tr>
        </thead>
        <tbody>
          <tr v-for="(r, i) in records" :key="i">
            <td>{{ r.time }}</td><td>{{ r.field }}</td><td>{{ r.before }}</td><td>{{ r.after }}</td><td>{{ r.operator }}</td>
          </tr>
          <tr v-if="!records.length"><td colspan="5" class="empty">暂无记录</td></tr>
        </tbody>
      </table>
    </BaseDialog>

    <!-- 主机设置 -->
    <BaseDialog v-model="showSettings" title="主机设置" width="420px">
      <div class="form-row">
        <label>主机名称</label>
        <input v-model.trim="settingsForm.name" type="text" class="form-input" />
      </div>
      <div class="form-row">
        <label>所属分组</label>
        <input :value="detail.group" type="text" class="form-input" disabled />
      </div>
      <template #footer>
        <button class="btn ghost" @click="showSettings = false">取消</button>
        <button class="btn primary" @click="saveSettings">保存</button>
      </template>
    </BaseDialog>
  </section>
</template>

<script setup>
import { ref, reactive } from 'vue'
import BaseDialog from './BaseDialog.vue'
import { updateInterval, getModifyRecords, updateHostSettings } from '../api'

const props = defineProps({
  detail: { type: Object, default: null },
  activeParam: { type: String, default: 'temp' }
})
const emit = defineEmits(['select-param', 'updated'])

const deviceImg = '/device.jpg'

// 修改采集间隔
const showInterval = ref(false)
const intervalForm = ref(1)
function openInterval() {
  intervalForm.value = props.detail.interval
  showInterval.value = true
}
async function saveInterval() {
  if (!intervalForm.value || intervalForm.value < 1) return
  await updateInterval(props.detail.id, intervalForm.value)
  showInterval.value = false
  emit('updated')
}

// 修改记录
const showRecords = ref(false)
const records = ref([])
async function openRecords() {
  showRecords.value = true
  records.value = await getModifyRecords(props.detail.id)
}

// 主机设置
const showSettings = ref(false)
const settingsForm = reactive({ name: '' })
function openSettings() {
  settingsForm.name = props.detail.name
  showSettings.value = true
}
async function saveSettings() {
  if (!settingsForm.name) return
  await updateHostSettings(props.detail.id, { name: settingsForm.name })
  showSettings.value = false
  emit('updated')
}
</script>

<style scoped>
.param-section {
  flex: none;
}

.info-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 8px;
  border: 1px solid #12406e;
  background: rgba(7, 20, 48, 0.6);
  margin-bottom: 8px;
}
.info-left {
  display: flex;
  align-items: center;
  gap: 26px;
}
.info-item {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #7d9cc9;
}
.info-item b {
  color: #d7e9ff;
  font-weight: 600;
}
.link {
  color: #3fa9f5;
  font-size: 12px;
  margin-left: 6px;
}
.link:hover {
  text-decoration: underline;
}
.st-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
}
.st-dot.online {
  background: #2fe08a;
  box-shadow: 0 0 6px rgba(47, 224, 138, 0.9);
}
.st-dot.offline {
  background: #f0a23c;
  box-shadow: 0 0 6px rgba(240, 162, 60, 0.9);
}
.st-online {
  color: #2fe08a !important;
}
.st-offline {
  color: #f0a23c !important;
}
.info-right {
  display: flex;
  align-items: center;
  gap: 8px;
}
.device-img {
  width: 44px;
  height: 44px;
  object-fit: cover;
  border: 1px solid #1d6bb0;
  border-radius: 2px;
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 8px;
}
.card-wrap {
  padding: 1px;
  cursor: pointer;
  clip-path: polygon(10px 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%, 0 10px);
  background: linear-gradient(135deg, #1d5a96, #123260);
  transition: filter 0.2s, background 0.2s;
}
.card-inner {
  height: 86px;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  clip-path: polygon(10px 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%, 0 10px);
  background: linear-gradient(160deg, #0e2c60 0%, #0a1c46 100%);
}
.card-wrap:hover,
.card-wrap.active {
  background: linear-gradient(135deg, #46c8ff, #1d7fd6);
  filter: drop-shadow(0 0 8px rgba(46, 160, 255, 0.45));
}
.card-top {
  display: flex;
  align-items: center;
  gap: 6px;
}
.card-name {
  font-size: 12px;
  color: #9cc0ee;
}
.card-swap {
  margin-left: auto;
  opacity: 0.8;
}
.card-value {
  display: flex;
  align-items: baseline;
  gap: 5px;
}
.card-value b {
  font-size: 24px;
  font-weight: 700;
  color: #fff;
  font-variant-numeric: tabular-nums;
}
.card-unit {
  font-size: 11px;
  color: #7d9cc9;
}

/* 表单 / 弹窗 */
.form-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
}
.form-row label {
  width: 64px;
  flex: none;
  color: #9cc0ee;
}
.form-input {
  flex: 1;
  height: 30px;
  padding: 0 10px;
  border: 1px solid #1d4670;
  border-radius: 3px;
  background: #081a3c;
  color: #d7e9ff;
  font-size: 13px;
}
.form-input:disabled {
  color: #4d6a99;
}
.form-unit {
  color: #7d9cc9;
}
.btn {
  height: 30px;
  padding: 0 18px;
  border-radius: 3px;
  font-size: 13px;
}
.btn.primary {
  background: linear-gradient(180deg, #1a7fd2, #0f56a4);
  border: 1px solid #3fa9f5;
  color: #fff;
}
.btn.ghost {
  border: 1px solid #1d4670;
  color: #9cc0ee;
  background: transparent;
}
.record-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}
.record-table th,
.record-table td {
  padding: 7px 8px;
  border-bottom: 1px solid #14335f;
  text-align: left;
  color: #b9d2f5;
  white-space: nowrap;
}
.record-table th {
  color: #6f92c4;
  font-weight: 500;
  background: rgba(18, 64, 120, 0.3);
}
.record-table .empty {
  text-align: center;
  color: #4d6a99;
}
</style>
