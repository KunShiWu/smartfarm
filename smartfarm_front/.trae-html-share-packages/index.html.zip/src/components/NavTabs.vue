<template>
  <nav class="nav-tabs">
    <div
      v-for="tab in tabs"
      :key="tab"
      class="tab-wrap"
      :class="{ active: modelValue === tab }"
      @click="$emit('update:modelValue', tab)"
    >
      <div class="tab-inner">{{ tab }}</div>
    </div>
  </nav>
</template>

<script setup>
defineProps({
  modelValue: { type: String, default: '首页' }
})
defineEmits(['update:modelValue'])

const tabs = ['首页', '实时数据', '历史数据', '主机列表', '视频监控', '设备控制', '数据集合', '报警管理']
</script>

<style scoped>
.nav-tabs {
  flex: none;
  display: flex;
  justify-content: center;
  gap: 26px;
  padding: 10px 0 8px;
}

.tab-wrap {
  width: 112px;
  height: 34px;
  padding: 1px;
  cursor: pointer;
  clip-path: polygon(10px 0, 100% 0, calc(100% - 10px) 100%, 0 100%);
  background: linear-gradient(135deg, #1d5a96, #123a68);
  transition: filter 0.2s;
}
.tab-inner {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  color: #9cc0ee;
  clip-path: polygon(10px 0, 100% 0, calc(100% - 10px) 100%, 0 100%);
  background: linear-gradient(180deg, #0d2653, #091a3c);
  transition: color 0.2s, background 0.2s;
}
.tab-wrap:hover .tab-inner {
  color: #d7e9ff;
}

.tab-wrap.active {
  background: linear-gradient(135deg, #46c8ff, #1d7fd6);
  filter: drop-shadow(0 0 8px rgba(46, 160, 255, 0.55));
}
.tab-wrap.active .tab-inner {
  color: #fff;
  font-weight: 600;
  background: linear-gradient(180deg, #1a7fd2, #0f56a4);
}
</style>
