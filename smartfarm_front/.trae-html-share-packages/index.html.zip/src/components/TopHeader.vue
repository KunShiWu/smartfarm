<template>
  <header class="top-header">
    <!-- 左:定位 + 天气 -->
    <div class="h-side h-left">
      <span class="loc">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none">
          <path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7z" fill="#e84c3d"/>
          <circle cx="12" cy="9" r="2.6" fill="#fff"/>
        </svg>
        {{ weather.city }}
      </span>
      <span class="weather">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none">
          <circle cx="9" cy="9" r="4" fill="#f5b73c"/>
          <path d="M6 17a3.5 3.5 0 0 1 .6-6.95A4.5 4.5 0 0 1 15 9.5a4 4 0 0 1 3.5 3.97A3 3 0 0 1 18 19.5H7z" fill="#e8eef7" opacity=".9"/>
        </svg>
        {{ weather.low }}-{{ weather.high }}℃
      </span>
    </div>

    <!-- 中:标题 -->
    <div class="h-center">
      <div class="wing left"></div>
      <div class="title-box">
        <h1 class="title">物联网监测系统</h1>
        <i class="title-glow"></i>
      </div>
      <div class="wing right"></div>
    </div>

    <!-- 右:时间 + 操作 -->
    <div class="h-side h-right">
      <span class="clock">{{ clock }}</span>
      <button class="tpl" title="查看模版" @click="todo('查看模版')">
        <svg viewBox="0 0 24 24" width="12" height="12" fill="none">
          <circle cx="12" cy="12" r="4.2" stroke="#f5b73c" stroke-width="1.6"/>
          <path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5 5l2.1 2.1M16.9 16.9 19 19M19 5l-2.1 2.1M7.1 16.9 5 19" stroke="#f5b73c" stroke-width="1.6" stroke-linecap="round"/>
        </svg>
        查看模版
      </button>
      <button class="h-btn" title="刷新数据" @click="$emit('refresh')">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none">
          <path d="M20 12a8 8 0 1 1-2.34-5.66" stroke="#8fb3e8" stroke-width="1.8" stroke-linecap="round"/>
          <path d="M20 3v4h-4" stroke="#8fb3e8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
      <button class="h-btn" title="布局设置" @click="todo('布局设置')">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none">
          <rect x="3" y="3" width="7.5" height="7.5" rx="1" stroke="#8fb3e8" stroke-width="1.6"/>
          <rect x="13.5" y="3" width="7.5" height="7.5" rx="1" stroke="#8fb3e8" stroke-width="1.6"/>
          <rect x="3" y="13.5" width="7.5" height="7.5" rx="1" stroke="#8fb3e8" stroke-width="1.6"/>
          <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1" stroke="#8fb3e8" stroke-width="1.6"/>
        </svg>
      </button>
      <button class="h-btn" title="全屏" @click="toggleFullscreen">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none">
          <path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5" stroke="#8fb3e8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
      <button class="h-btn power" title="退出系统" @click="todo('退出系统')">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none">
          <path d="M12 3v8" stroke="#e86a6a" stroke-width="1.8" stroke-linecap="round"/>
          <path d="M6.3 6.3a8 8 0 1 0 11.4 0" stroke="#e86a6a" stroke-width="1.8" stroke-linecap="round"/>
        </svg>
      </button>
    </div>

    <div v-if="toast" class="toast">{{ toast }}</div>
  </header>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { getWeather } from '../api'

defineEmits(['refresh'])

const pad = (n) => String(n).padStart(2, '0')
const weekMap = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']

const clock = ref('')
const weather = ref({ city: '厦门市', low: 23, high: 34 })
const toast = ref('')
let timer = null
let toastTimer = null

function tick() {
  const d = new Date()
  clock.value =
    `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} ${weekMap[d.getDay()]}`
}

function toggleFullscreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen()
  } else {
    document.documentElement.requestFullscreen()
  }
}

function todo(name) {
  toast.value = `「${name}」功能待接入`
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => (toast.value = ''), 2000)
}

onMounted(async () => {
  tick()
  timer = setInterval(tick, 1000)
  try {
    weather.value = await getWeather()
  } catch (e) {
    // 接口异常时保持默认天气
  }
})

onUnmounted(() => {
  clearInterval(timer)
  clearTimeout(toastTimer)
})
</script>

<style scoped>
.top-header {
  position: relative;
  height: 64px;
  flex: none;
  background: linear-gradient(180deg, #0a1c44 0%, #07122f 100%);
  border-bottom: 1px solid #12365f;
}

.h-side {
  position: absolute;
  top: 0;
  height: 100%;
  display: flex;
  align-items: center;
  gap: 14px;
  z-index: 2;
}
.h-left {
  left: 14px;
}
.h-right {
  right: 14px;
  gap: 10px;
}

.loc {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #cfe2ff;
}
.weather {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  color: #8fb3e8;
}

.clock {
  font-size: 12px;
  color: #8fb3e8;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.tpl {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #f5d78a;
}

.h-btn {
  width: 24px;
  height: 24px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #1d4670;
  border-radius: 3px;
  background: #0b2048;
  transition: background 0.2s, border-color 0.2s;
}
.h-btn:hover {
  background: #123368;
  border-color: #2a6bb0;
}

/* 标题 */
.h-center {
  position: absolute;
  left: 50%;
  top: 0;
  transform: translateX(-50%);
  height: 100%;
  display: flex;
  align-items: center;
}

.title-box {
  position: relative;
  width: 400px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  clip-path: polygon(0 0, 100% 0, calc(100% - 26px) 100%, 26px 100%);
  background: linear-gradient(180deg, rgba(23, 84, 156, 0.85) 0%, rgba(10, 34, 76, 0.95) 100%);
}
.title {
  font-size: 26px;
  font-weight: 700;
  letter-spacing: 10px;
  text-indent: 10px;
  color: #eaf4ff;
  text-shadow: 0 0 14px rgba(64, 170, 255, 0.85);
  white-space: nowrap;
}
.title-glow {
  position: absolute;
  left: 8%;
  right: 8%;
  bottom: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, #3fd2ff 30%, #8fe9ff 50%, #3fd2ff 70%, transparent);
}

.wing {
  width: 130px;
  height: 14px;
  clip-path: polygon(0 100%, 100% 100%, 100% 0, 12px 100%);
  background: linear-gradient(90deg, transparent, rgba(32, 110, 190, 0.7));
  align-self: flex-end;
  margin-bottom: 8px;
}
.wing.left {
  transform: scaleX(-1);
  margin-right: -6px;
}
.wing.right {
  margin-left: -6px;
}

.toast {
  position: absolute;
  top: 70px;
  left: 50%;
  transform: translateX(-50%);
  padding: 6px 16px;
  background: rgba(10, 34, 76, 0.95);
  border: 1px solid #2a6bb0;
  border-radius: 3px;
  font-size: 12px;
  color: #cfe2ff;
  z-index: 99;
}
</style>
