<template>
  <div class="screen">
    <TopHeader @refresh="reload" />
    <NavTabs v-model="activeTab" />

    <div class="content">
      <SidePanel :hosts="hosts" v-model="selectedHostId" @select="onSelectHost" />

      <main class="main">
        <template v-if="showDashboard && hostDetail">
          <ParamCards
            :detail="hostDetail"
            :active-param="activeParam"
            @select-param="activeParam = $event"
            @updated="reload"
          />
          <RealtimeChart
            ref="chartRef"
            :host-id="selectedHostId"
            :param-meta="hostDetail.paramMeta"
            :active-param="activeParam"
          />
        </template>

        <div v-else-if="showDashboard" class="loading">数据加载中…</div>

        <div v-else class="placeholder">
          <svg viewBox="0 0 24 24" width="42" height="42" fill="none">
            <rect x="3" y="4" width="18" height="14" rx="2" stroke="#1d6bb0" stroke-width="1.5"/>
            <path d="M3 9h18M8 21h8M12 18v3" stroke="#1d6bb0" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <p>「{{ activeTab }}」模块建设中,接口已预留</p>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import TopHeader from './components/TopHeader.vue'
import NavTabs from './components/NavTabs.vue'
import SidePanel from './components/SidePanel.vue'
import ParamCards from './components/ParamCards.vue'
import RealtimeChart from './components/RealtimeChart.vue'
import { getHostList, getRealtimeParams } from './api'

const activeTab = ref('首页')
const hosts = ref([])
const selectedHostId = ref('')
const hostDetail = ref(null)
const activeParam = ref('temp')
const chartRef = ref(null)

// 首页与实时数据页均展示监控大屏
const showDashboard = computed(() => ['首页', '实时数据'].includes(activeTab.value))

async function loadDetail() {
  if (!selectedHostId.value) return
  hostDetail.value = await getRealtimeParams(selectedHostId.value)
}

function onSelectHost() {
  loadDetail()
}

async function reload() {
  await loadDetail()
  chartRef.value && chartRef.value.reload()
}

onMounted(async () => {
  hosts.value = await getHostList()
  if (hosts.value.length) {
    selectedHostId.value = hosts.value[0].id
    await loadDetail()
  }
})
</script>

<style scoped>
.screen {
  height: 100vh;
  min-width: 1180px;
  min-height: 660px;
  display: flex;
  flex-direction: column;
  background:
    radial-gradient(1200px 500px at 50% -10%, rgba(20, 70, 140, 0.35), transparent 70%),
    linear-gradient(180deg, #060c26 0%, #04081a 100%);
  overflow: auto;
}

.content {
  flex: 1;
  min-height: 0;
  display: flex;
  gap: 8px;
  padding: 0 10px 10px;
}

.main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
}

.loading,
.placeholder {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: #4d6a99;
  border: 1px solid #12406e;
  background: rgba(7, 20, 48, 0.6);
  font-size: 13px;
}
</style>
