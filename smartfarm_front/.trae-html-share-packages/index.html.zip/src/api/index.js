import request from './request'
import * as mock from './mock'

// 默认使用 mock 数据;后端就绪后,在 .env 中设置 VITE_USE_MOCK=false
// 并配置 VITE_API_BASE_URL 或 vite 代理即可切换到真实接口
const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

// 获取天气信息
export const getWeather = () =>
  USE_MOCK ? mock.getWeather() : request.get('/weather')

// 获取主机列表
export const getHostList = () =>
  USE_MOCK ? mock.getHostList() : request.get('/hosts')

// 获取主机实时参数
export const getRealtimeParams = (hostId) =>
  USE_MOCK ? mock.getRealtimeParams(hostId) : request.get(`/hosts/${hostId}/realtime`)

// 获取实时曲线数据
export const getRealtimeChart = (hostId) =>
  USE_MOCK ? mock.getRealtimeChart(hostId) : request.get(`/hosts/${hostId}/realtime/chart`)

// 修改采集间隔
export const updateInterval = (hostId, interval) =>
  USE_MOCK ? mock.updateInterval(hostId, interval) : request.put(`/hosts/${hostId}/interval`, { interval })

// 获取修改记录
export const getModifyRecords = (hostId) =>
  USE_MOCK ? mock.getModifyRecords(hostId) : request.get(`/hosts/${hostId}/modify-records`)

// 保存主机设置
export const updateHostSettings = (hostId, payload) =>
  USE_MOCK ? mock.updateHostSettings(hostId, payload) : request.put(`/hosts/${hostId}/settings`, payload)
