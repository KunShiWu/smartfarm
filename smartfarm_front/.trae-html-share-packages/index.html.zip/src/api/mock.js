// Mock 数据层:后端接口未接入前,为前端页面提供数据
// 数据结构即前后端约定结构,后端按此返回即可无缝替换

const pad = (n) => String(n).padStart(2, '0')
const fmt = (d) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
  `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`

// 参数元信息(8 参数)
const paramMeta = [
  { key: 'temp', name: '土壤温度', unit: '℃' },
  { key: 'humidity', name: '土壤湿度', unit: '%' },
  { key: 'ec', name: '土壤电导率', unit: 'uS/cm' },
  { key: 'salt', name: '土壤盐分', unit: 'mg/L' },
  { key: 'nitrogen', name: '土壤氮含量', unit: 'mg/kg' },
  { key: 'phosphorus', name: '土壤磷含量', unit: 'mg/kg' },
  { key: 'potassium', name: '土壤钾含量', unit: 'mg/kg' },
  { key: 'ph', name: '土壤pH值', unit: '' }
]

// 主机 store(模拟数据库)
const hosts = [
  {
    id: 'host-001',
    name: '4G低功耗土壤8参数检测仪',
    group: '土壤检测',
    online: false,
    battery: 3.7,
    interval: 1, // 采集间隔(分钟)
    collectTime: '2026-10-11 15:57:23',
    params: {
      temp: 27.2,
      humidity: 100.0,
      ec: 1031,
      salt: 689,
      nitrogen: 131,
      phosphorus: 34,
      potassium: 174,
      ph: 6.96
    }
  }
]

// 修改记录 store
const modifyRecords = [
  { time: '2026-10-11 15:57:23', field: '采集间隔', before: '5分钟', after: '1分钟', operator: 'admin' },
  { time: '2026-10-10 09:12:05', field: '主机名称', before: '土壤检测仪', after: '4G低功耗土壤8参数检测仪', operator: 'admin' }
]

// 曲线历史值(与 collectTime 对齐,向左每 7 分钟一个点)
const chartValues = {
  temp: [28, 29.5, 32.8, 40, 40, 24.7, 25, 25.2],
  humidity: [98, 99, 100, 100, 100, 99.5, 99.8, 100],
  ec: [1020, 1025, 1031, 1033, 1030, 1028, 1029, 1031],
  salt: [680, 685, 689, 692, 690, 688, 687, 689],
  nitrogen: [128, 130, 131, 132, 131, 130, 129, 131],
  phosphorus: [33, 34, 34, 35, 34, 34, 33, 34],
  potassium: [170, 172, 174, 175, 174, 173, 172, 174],
  ph: [6.9, 6.95, 6.96, 6.98, 6.96, 6.94, 6.95, 6.96]
}

const delay = (data, ms = 200) =>
  new Promise((resolve) => setTimeout(() => resolve(JSON.parse(JSON.stringify(data))), ms))

// 天气信息
export function getWeather() {
  return delay({ city: '厦门市', text: '多云', low: 23, high: 34 })
}

// 主机列表
export function getHostList() {
  return delay(hosts)
}

// 主机实时参数
export function getRealtimeParams(hostId) {
  const host = hosts.find((h) => h.id === hostId)
  if (!host) return delay(null)
  return delay({
    ...host,
    paramMeta,
    params: paramMeta.map((m) => ({ ...m, value: host.params[m.key] }))
  })
}

// 实时曲线
export function getRealtimeChart(hostId) {
  const host = hosts.find((h) => h.id === hostId)
  if (!host) return delay(null)
  const times = []
  const end = new Date(host.collectTime.replace(/-/g, '/'))
  for (let i = 0; i < 8; i++) {
    times.push(fmt(new Date(end.getTime() - i * 7 * 60 * 1000)))
  }
  const series = {}
  Object.keys(chartValues).forEach((k) => {
    series[k] = chartValues[k].slice()
  })
  return delay({ times, series })
}

// 修改采集间隔
export function updateInterval(hostId, interval) {
  const host = hosts.find((h) => h.id === hostId)
  if (!host) return delay(null)
  modifyRecords.unshift({
    time: fmt(new Date()),
    field: '采集间隔',
    before: `${host.interval}分钟`,
    after: `${interval}分钟`,
    operator: 'admin'
  })
  host.interval = interval
  return delay({ success: true })
}

// 修改记录
export function getModifyRecords() {
  return delay(modifyRecords)
}

// 主机设置
export function updateHostSettings(hostId, payload) {
  const host = hosts.find((h) => h.id === hostId)
  if (!host) return delay(null)
  if (payload.name && payload.name !== host.name) {
    modifyRecords.unshift({
      time: fmt(new Date()),
      field: '主机名称',
      before: host.name,
      after: payload.name,
      operator: 'admin'
    })
    host.name = payload.name
  }
  return delay({ success: true })
}
